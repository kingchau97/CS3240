# project-b-13
This is a semester long project for UVA fall 2021's CS 3240 course, Advanced Software Development Techniques. 
We are building an off-grounds housing web application using Python, Django, Bootstrap, Heroku, etc.
